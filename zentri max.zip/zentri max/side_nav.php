
			<aside id="main-sidebar-wrapper" class="col-md-pull-9 col-lg-3 col-md-3 col-sm-12 col-xs-24">

	<h2 class="heading">Our Categories</h2>

	<ul id="menu4" class="menu collapsible">
		<li class="msec_menu"><a href="products.php?cat=featured" class="mcat current"><b>Feature Products</b></a></li>
		<li class="msec_menu">
		<strong><b>Sports Wear</b></strong><ul>
			<span class="submenu" id="sub1"><li>
				<a class="submenu_link" href="products.php?cat=footballplayeruniforms">Football Player Uniforms</a></li>
				<li><a class="submenu_link" href="products.php?cat=goalkeeperuniforms">Goal Keeper Uniforms</a></li>
				
				<li><a class="submenu_link" href="products.php?cat=trainingvests">Training Vests</a>
				</li><li><a class="submenu_link" href="products.php?cat=tracksuits">Track Suits</a>
				</li><li><a class="submenu_link" href="products.php?cat=ladiessuits">Ladies Suits</a>
				</li><li><a class="submenu_link" href="products.php?cat=basketballuniforms">BasketBall Uniforms</a>
				</li><li>
					<a class="submenu_link" href="products.php?cat=icehockeyjerseys">Ice Hockey Uniforms</a>
				</li>
			</span></ul></li>

				<li class="msec_menu"><strong><b>Gloves</b></strong><ul><span class="submenu" id="sub3"><li><a class="submenu_link" href="products.php?cat=mechanicgloves">Mechanics Gloves</a></li><li><a class="submenu_link" href="products.php?cat=cyclinggloves">Cycling Gloves</a></li><li><a class="submenu_link" href="products.php?cat=weightliftinggloves">Weight Lifting Gloves</a></li></span></ul></li>

				<li class="msec_menu"><strong><b>Jackets</b></strong><ul><span class="submenu" id="sub4"><li><a class="submenu_link" href="products.php?cat=leatherjackets">Leather Jackets</a></li><li><a class="submenu_link" href="products.php?cat=rainjackets">Rain Jackets</a></li><li><a class="submenu_link" href="products.php?cat=bubblejacket">Bubble Jackets</a></li></span></ul></li>

				<li class="msec_menu"><strong><b>Fitness Gear</b></strong><ul><span class="submenu" id="sub5"><li><a class="submenu_link" href="products.php?cat=gymshirts">Gym Shirts</a></li><li><a class="submenu_link" href="products.php?cat=gymsinglets">Gym Singlets</a></li><li><a class="submenu_link" href="products.php?cat=gymjerseys">Gym Jerseys</a></li><li><a class="submenu_link" href="products.php?cat=gym shorts">Gym Shorts</a></li><li><a class="submenu_link" href="products.php?cat=ladiesgymshirts">Ladies Gym Shirts</a></li><li><a class="submenu_link" href="products.php?cat=ladiestanktops">Ladies Tank Tops</a></li><li><a class="submenu_link" href="products.php?cat=ladiesbras">Ladies Bras</a></li><li><a class="submenu_link" href="products.php?cat=ladiesgymleggings">Ladies Gym Leggings</a></li><li><a class="submenu_link" href="products.php?cat=ladiesshorts">Ladies Shorts</a></li></span></ul></li>

				<li class="msec_menu"><strong><b>Compression Wear</b></strong><ul><span class="submenu" id="sub6"><li><a class="submenu_link" href="products.php?cat=compressionshirtshortsleeves">Compression Shirt </a></li><li><a class="submenu_link" href="products.php?cat=compressionpants">Compression Pants</a></li><li><a class="submenu_link" href="products.php?cat=compressionshorts">Compression Shorts</a></li></span></ul></li>

				<li class="msec_menu"><strong><b>Running Wear </b></strong><ul><span class="submenu" id="sub7"><li><a class="submenu_link" href="products.php?cat=runningjerseys">Running Jerseys</a></li><li><a class="submenu_link" href="products.php?cat=runningshirts">Running Shirts</a></li><li><a class="submenu_link" href="products.php?cat=runningsuits">Running Suits</a></li><li><a class="submenu_link" href="products.php?cat=runningtrousers">Running Trousers</a></li><li><a class="submenu_link" href="products.php?cat=runningshorts">Running Shorts</a></li><li><a class="submenu_link" href="products.php?cat=ladiesjerseys">Ladies Jerseys</a></li><li><a class="submenu_link" href="products.php?cat=ladiessuits">Ladies Suits</a></li><li><a class="submenu_link" href="products.php?cat=ladiesshirts">Ladies Shirts</a></li><li><a class="submenu_link" href="products.php?cat=ladiesleggings">Ladies Leggings</a></li><li><a class="submenu_link" href="products.php?cat=ladiesshorts">Ladies Shorts</a></li></span></ul></li>

				<li class="msec_menu"><a href="products.php?cat=deniemjeans" class="mcat current"><b>Deinem & Jeans</b></a></li>

			<li class="msec_menu"><a href="products.php?cat=judosuits" class="mcat current"><b>Judo & Krate Suits</b></a></li>

			<li class="msec_menu"><a href="products.php?cat=motorbikesuits" class="mcat current"><b>Motorbike Suits</b></a></li>
			<li class="msec_menu"><a href="products.php?cat=sublimationtshirts" class="mcat current"><b>Sublimation T-Shirts</b></a></li>
			



		</ul><div class="fl_clear"></div>
	
		<div class="toppad_30">

			
	
	
</aside>
