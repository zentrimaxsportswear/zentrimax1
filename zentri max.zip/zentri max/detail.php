<?php include'header.php ';

include('hasprises/connection.php');

if(isset($_GET['proid']))
{
	$pro_id = $_GET['proid'];
	
	$sql = mysql_query("SELECT * FROM products WHERE pro_id='$pro_id'");
	
	while($row=mysql_fetch_array($sql))
	{
			
		$cat=$row['category'];
		$name=$row['pro_name'];
		$model=$row['model'];
		$color=$row['color'];
		$desc=$row['description'];
		$proimg=$row['pro_img']; if($proimg=="") {$proimg="noimg.jpg";}
		$img="images/products/".$proimg;
		
	}
	
}



 ?>
<br><br><br><br><br><br>
    <div class="container-fluid">

	
	<section id="page-wrapper">

		<div class="">

			
			<div class="row">

			<div id="page-content-wrapper" class="col-md-push-3 col-lg-9 col-md-9 col-sm-12 col-xs-24">

				<h2 class="heading"><span>Products Detail</span></h2>

				<div class="row">

					
						
						<div id="main-prd-img" class="col-lg-8 col-md-8 col-sm-8 col-xs-24">
						    
						    						    <div id="g_wrapper" class="text-center"><img id="mdelimg" style="max-height:400px; max-width:400px; display:inline-block;" src="<?php echo $img; ?>" data-zoom-image="<?php echo $img; ?>" alt="" ></div>

                			                			
						</div>

						<div id="main-prd-detail" class="col-lg-4 col-md-4 col-sm-4 col-xs-24">

							<div id="singprdwrapper_txt_art"><strong>Product Name:</strong><h3 style="font-style: bold;"><?php echo $name; ?></h3></div>
														
							

						</div>
						<div id="main-prd-detail" class="col-lg-4 col-md-4 col-sm-4 col-xs-24">

							<div id="singprdwrapper_txt_art"><strong>Category:</strong><h3><?php $cat; ?></h3></div>
														<div id="singprdwrapper_txt_detail"><strong class="txt_detail">Description:</strong><h4><?php echo $desc; ?></h4></div>
														<div id="singprdwrapper_txt_detail"><strong class="txt_detail">Colour:</strong><h4><?php echo $color; ?> Available</h4></div>
							

						</div>


												<div class="col-lg-12 col-md-12 col-sm-12 col-xs-24 toppad_30">
							<div class="row">
								
							</div>
						</div>
						
					
				</div>

			</div>

		<?php include 'side_nav.php'; ?>

		</div>

		</div>

	</section>

        
    <?php include'footer.php '; ?>