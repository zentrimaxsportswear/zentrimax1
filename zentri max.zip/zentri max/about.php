<?php
include'header.php';
?>

       
       <br><br><br><br><br><br><br><br><br><br><br><br>

        <div class="tm-bottom-a-box  ">
            <div class="uk-container uk-container-center">
                <section id="tm-bottom-a" class="tm-bottom-a uk-grid" data-uk-grid-match="{target:'> div > .uk-panel'}" data-uk-grid-margin="">

                    <div class="uk-width-1-1 uk-row-first">
                        <div class="uk-panel">
                            <div class="about-team-page-top-wrap">
                                <div class="uk-grid">
                                    <div class="uk-width-large-5-10 uk-width-small-1-1 left-part">
                                        <div class="top-title">
                                            <h2>About <span>Us</span></h2>
                                        </div>
                                        <p>Zentri Max, as Manufacturing and Exporting Company in Sialkot Pakistan.

Since then continues to expand and increase more business in Global Main Markets. I addition to Sports Goods, all kinds of Gloves and Sports Wears are also produced & exported by the company.

The company is leading industry and lead in expertise, innovation, designing and imprinting. The qualified team with extensive experience in the field of manufacturing and exporting manages the company.

Most vigilant, quality experts control the quality standards. The production capacity of the Company is flexible to meet the production of big quantity orders. The deliveries are timely and prices are most reasonable.

                                                       <b>  </b></p>
                                    </div>
                                
                                        <div class="uk-width-large-5-10 uk-width-small-1-1 right-part">
                                            <img src="images/slider/hasprises.png" height="100px" >
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>

        <div class="tm-bottom-b-box tm-full-width  ">
            <div class="uk-container uk-container-center">
                <section id="tm-bottom-b" class="tm-bottom-b uk-grid" data-uk-grid-match="{target:'> div > .uk-panel'}" data-uk-grid-margin="">

                   
                </section>
            </div>
        </div>

       


        <?php   
            include'footer.php';
        ?>