<?php include'header.php'; ?>

       

        

        <div class="tm-bottom-a-box  ">
            <div class="uk-container uk-container-center">
                <section id="tm-bottom-a" class="tm-bottom-a uk-grid" data-uk-grid-match="{target:'> div > .uk-panel'}" data-uk-grid-margin="">
                    <div class="uk-width-1-1 uk-row-first">
                        <div class="uk-panel">
                            <div class="contact-page">
                                <div class="uk-grid">
                                    <div class="uk-width-1-1">
                                        <div class="contact-title">
<br><br><br><br><br>><br><br>   <h3 style="color: red;">Contact US:</h3>                                        </div>
                                       
                                    </div>
                                    <div class="uk-width-1-1">
                                        <div class="contact-socials-wrap">
                                            <ul class="contact-socials">
                                                <li><a href="tel:+923147839420"><i class="uk-icon-whatsapp"></i></a></li>
                                          
                                                <li><a href="mailto:zentrimaxsportswear@gmail.com"><i class="uk-icon-google"></i></a></li>
                                                <li><a href="#"><span class="uk-icon-small uk-icon-hover uk-icon-instagram"><i class="uk-icon-instagram"></i></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="uk-grid" data-uk-grid-match="{target:'.contact-enquiries'}">
                                    
                                  
                                    <div class="uk-width-medium-1-9 uk-panel">
                                        <div style="min-height: 139px;" class="contact-enquiries">
                                            <div class="title">Zentri Max</div>
                                            <div class="phone"><i class="uk-icon-phone"></i>+923147839420</div>
                                            <div class="mail">
                                                <i class="uk-icon-envelope"></i>
                                                <a href="malto:zentrimaxsportswear@gmail.com">
                                                   zentrimaxsportswear@gmail.com
                                                </a>
                                            </div>
                                            <div class="location"><i class="uk-icon-map-marker"></i>Sialkot, 51310 Pakistan.</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>

        <div class="tm-bottom-b-box tm-full-width  ">
            <div class="uk-container uk-container-center">
                <section id="tm-bottom-b" class="tm-bottom-b uk-grid uk-grid-collapse" data-uk-grid-match="{target:'> div > .uk-panel'}" data-uk-grid-margin="">

                    
                </section>
            </div>
        </div>

       <?php include 'footer.php'; ?>