  <footer>
    
    <div class="footer_bg">
      <div class="container">
        <div class="row">
           
        </div>
      </div>
    </div>
    
    <div class="bg_color4">
      <div class="copyright">
         <font color="white" style="align:center;">Copyrights 2019 HASPRISES INTERNATIONAL. Developed by BADRI.</font>
      </div>
    </div>
    
  </footer>
   

    <a href="#0" class="cd-top">Top</a> 
