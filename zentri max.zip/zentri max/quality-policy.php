<?php
    include'header.php';

?>
       <br><br><br><br><br><br><br><br><br><br><br><br>

    <div class="container-fluid">


    <section id="tm-bottom-a" class="tm-bottom-a uk-grid" data-uk-grid-match="{target:'> div > .uk-panel'}" data-uk-grid-margin="">

                    <div class="uk-width-1-1 uk-row-first">
                        <div class="uk-panel">
                            <div class="about-team-page-top-wrap">
                                <div class="uk-grid">
                                    <div class="uk-width-large-5-10 uk-width-small-1-1 left-part">
                                        <div class="top-title">
                                            &ensp;&ensp;&ensp;<h2>Quality <span>Policy</span></h2>
                                        </div>
                                        <p><span>In modern day markets, quality has become a major economic factor. Customers not only require a fast and efficient delivery of data, but also 100 percent accuracy of the data provided.</span><span></span></p>
<p>Moreover, professional services and an excellent customer support are the basis of any customer relationship.To verify our commitment to consistently meeting and exceeding customers&rsquo; expectations, we submit ourselves to critical external audits for review and certification of our services.</p>
                                    </div>
                                
                                        <div class="uk-width-large-5-10 uk-width-small-1-1 right-part">
                                            <img src="images/slider/hasprises.png" height="100px" >
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>

        
<?php

        include'footer.php';

?>