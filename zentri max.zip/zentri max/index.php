<?php include'header.php';

 ?>

        <div class="tm-top-a-box tm-full-width  ">
            <div class="uk-container uk-container-center">
                <section id="tm-top-a" class="tm-top-a uk-grid uk-grid-collapse" data-uk-grid-match="{target:'> div > .uk-panel'}" data-uk-grid-margin="">

                    <div class="uk-width-1-1">
                        <div class="uk-panel">
                            <div class="akslider-module ">
                                <div class="uk-slidenav-position" data-uk-slideshow="{height: 'auto', animation: 'swipe', duration: '500', autoplay: true, autoplayInterval: '3000', videoautoplay: true, videomute: true, kenburns: false}">
                                    <ul class="uk-slideshow uk-overlay-active">
                                        <li aria-hidden="false" class="uk-height-viewport uk-active">
                                            <div style="background-image: url(images/slider/7g4m8e1l7h.jpg);" class="uk-cover-background uk-position-cover"></div><img style="width: 100%; height: auto; opacity: 0;" class="uk-invisible" src="images/slider/7.jpg" alt="">
                                            <div class="uk-position-cover uk-flex-middle">
                                                <div class="uk-container uk-container-center uk-position-cover">
                                                    
                                                </div>
                                            </div>
                                        </li>
                                        <li aria-hidden="true" class="uk-height-viewport">
                                            <div style="background-image: url(images/slider/2.jpg;);" class="uk-cover-background uk-position-cover"></div><img style="width: 100%; height: auto; opacity: 0;" class="uk-invisible" src="images/slider/2.jpg" alt="">
                                            <div class="uk-position-cover uk-flex-middle">
                                                <div class="uk-container uk-container-center uk-position-cover">
                                                    
                                                </div>
                                            </div>
                                        </li>
                                        <li aria-hidden="true" class="uk-height-viewport">
                                            <div style="background-image: url(images/slider/3.jpg;);" class="uk-cover-background uk-position-cover"></div><img style="width: 100%; height: auto; opacity: 0;" class="uk-invisible" src="images/slider/3.jpg" alt="">
                                            <div class="uk-position-cover uk-flex-middle">
                                                <div class="uk-container uk-container-center uk-position-cover">
                                                    
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                    <a href="/" class="uk-slidenav uk-slidenav-contrast uk-slidenav-previous" data-uk-slideshow-item="previous"></a>
                                    <a href="/" class="uk-slidenav uk-slidenav-contrast uk-slidenav-next" data-uk-slideshow-item="next"></a>
                                    <ul class="uk-dotnav uk-dotnav-contrast uk-position-bottom uk-text-center">
                                        <li class="uk-active" data-uk-slideshow-item="0"><a href="/">0</a>
                                        </li>
                                        <li data-uk-slideshow-item="1"><a href="/">1</a>
                                        </li>
                                        <li data-uk-slideshow-item="2"><a href="/">2</a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>
        <!--Sliders End-->
        <!---->

        <br><br>
      <div class="uk-container uk-container-center">
            <div id="tm-middle" class="tm-middle uk-grid" data-uk-grid-match="" data-uk-grid-margin="">
                <div class="tm-main uk-width-medium-1-1 uk-row-first">
                    <main id="tm-content" class="tm-content">
                        <div id="system-message-container"></div>
                        <div class="jshop" id="comjshop">
                            <h1 align="center">Our <span style="color: red;">Products</span></h1>
                            <div class="jshop_list_category">
                            </div>
                            <div class="jshop_list_product">
                                <br>
                               
                                <div class="jshop list_product" id="comjshop_list_product">
                                    <div class="list_product_row uk-grid" data-uk-grid-match="{target:'.uk-panel'}">
                                        <div class="uk-width-medium-1-4 uk-panel jswidth25 block_product">
                                            <div class="product productitem_14">
                                                <div class="image">
                                                    <div class="image_block">
                                                        <div class="product_label">
                                                        </div>
                                                        <a href="">
                                                        <img class="jshop_img" src="images/index/5.jpg" style="height: 300px;" alt="" title="">
                                                        </a>
                                                        <div class="name">
                                                            <h2 class="product_title"><a href="detail.php?proid=107">Ladies Suits</a></h2>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="mainblock">
                                                    <div class="price-wrap">
                                                        <div class="jshop_price" style="color: white;"><span>
                                                            Art no.</span>
                                                        </div>
                                                        <div class="jshop_price">
                                                            <span>120</span>
                                                        </div>
                                                    </div>
                                                    <div class="buttons">
                                                        <a class="button_buy" href="detail.php?proid=107">View</a> &nbsp;
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="uk-width-medium-1-4 uk-panel jswidth25 block_product">
                                            <div class="product productitem_5">
                                                <div class="image">
                                                    <div class="image_block">
                                                        <div class="product_label">
                                                        </div>
                                                        <a href="product.html">
                                                        <img class="jshop_img" src="images/index/7.jpg" style="height: 300px;" alt="" title="">
                                                        </a>
                                                        <div class="name">
                                                            <h2 class="product_title"><a href="detail.php?proid=272">Bubbule Jackets</a></h2>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="mainblock">
                                                    <div class="price-wrap">
                                                        <div class="jshop_price" style="color: white;"><span>
                                                            Art no.</span>
                                                        </div>
                                                        <div class="jshop_price">
                                                            <span>078</span>
                                                        </div>
                                                    </div>
                                                    <div class="buttons">
                                                        <a class="button_buy" href="detail.php?proid=272">View</a> &nbsp;
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="uk-width-medium-1-4 uk-panel jswidth25 block_product">
                                            <div class="product productitem_16">
                                                <div class="image">
                                                    <div class="image_block">
                                                        <a href="detail.php?proid=273">
                                                        <img class="jshop_img" src="images/pic/IMG-20190221-WA0023.jpg" style="height: 300px;" alt="" title="">
                                                        </a>
                                                        <div class="name">
                                                            <h2 class="product_title"><a href="detail.php?proid=273">Running Shirts</a></h2>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="mainblock">
                                                    <div class="price-wrap">
                                                        <div class="jshop_price" style="color: white;"><span>
                                                            Art no.</span>
                                                        </div>
                                                        <div class="jshop_price">
                                                            <span>121</span>
                                                        </div>
                                                    </div>
                                                    <div class="buttons">
                                                        <a class="button_buy" href="detail.php?proid=273">View</a> &nbsp;
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="uk-width-medium-1-4 uk-panel jswidth25 block_product">
                                            <div class="product productitem_12">
                                                <div class="image">
                                                    <div class="image_block">
                                                        <a href="detail.php?proid=88">
                                                        <img class="jshop_img" src="images/pic/IMG-20190221-WA0011.jpg" style="height: 300px;" alt="" title="">
                                                        </a>
                                                        <div class="name">
                                                            <h2 class="product_title"><a href="detail.php?proid=88">Men Track</a></h2>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="mainblock">
                                                    <div class="price-wrap">
                                                        <div class="jshop_price" style="color: white;"><span>
                                                            Art no.</span>
                                                        </div>
                                                        <div class="jshop_price">
                                                            <span>120</span>
                                                        </div>
                                                    </div>
                                                    <div class="buttons">
                                                        <a class="button_buy" href="detail.php?proid=88">View</a> &nbsp;
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="nvg_clear"></div>
                                    <div class="list_product_row uk-grid" data-uk-grid-match="{target:'.uk-panel'}">
                                        <div class="uk-width-medium-1-4 uk-panel jswidth25 block_product">
                                            <div class="product productitem_2">
                                                <div class="image">
                                                    <div class="image_block"  >
                                                        <a href="detail.php?proid=274">
                                                        <img class="jshop_img" src="images/pic/IMG-20190221-WA0030.jpg" style="height: 300px;" alt=" Hoodie" title="Hoodie">
                                                        </a>
                                                        <div class="name">
                                                            <h2 class="product_title"><a href="detail.php?proid=274">Men's  Hoodie</a></h2>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="mainblock">
                                                    <div class="price-wrap">
                                                        <div class="jshop_price" style="color: white;"><span>
                                                            Art no.</span>
                                                        </div>
                                                        <div class="jshop_price">
                                                            <span>120</span>
                                                        </div>
                                                    </div>
                                                    <div class="buttons">
                                                        <a class="button_buy" href="detail.php?proid=274">View</a> &nbsp;
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="uk-width-medium-1-4 uk-panel jswidth25 block_product">
                                            <div class="product productitem_1">
                                                <div class="image">
                                                    <div class="image_block">
                                                        <div class="product_label">
                                                        </div>
                                                        <a href="detail.php?proid=275">
                                                        <img class="jshop_img" src="images/pic/IMG-20190221-WA0034.jpg" style="height: 300px;" alt="hoodie" title="hoodie">
                                                        </a>
                                                        <div class="name">
                                                            <h2 class="product_title"><a href="detail.php?proid=275">Hoodies</a></h2>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="mainblock">
                                                    <div class="price-wrap">
                                                        <div class="jshop_price" style="color: white;"><span>
                                                            Art no.</span>
                                                        </div>
                                                        <div class="jshop_price">
                                                            <span>78</span>
                                                        </div>
                                                    </div>
                                                    <div class="buttons">
                                                        <a class="button_buy" href="detail.php?proid=275">View</a> &nbsp;
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="uk-width-medium-1-4 uk-panel jswidth25 block_product">
                                            <div class="product productitem_7">
                                                <div class="image">
                                                    <div class="image_block">
                                                        <div class="product_label">
                                                        </div>
                                                        <a href="detail.php?proid=276">
                                                        <img class="jshop_img" src="images/pic/IMG-20190221-WA0038.jpg" style="height: 300px;" alt="Hoodies" title="Hoodies">
                                                        </a>
                                                        <div class="name">
                                                            <h2 class="product_title"><a href="detail.php?proid=276">Hoodies</a></h2>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="mainblock">
                                                    <div class="price-wrap">
                                                        <div class="jshop_price" style="color: white;"><span>
                                                            Art no.</span>
                                                        </div>
                                                        <div class="jshop_price">
                                                            <span>78</span>
                                                        </div>
                                                    </div>
                                                    <div class="buttons">
                                                        <a class="button_buy" href="detail.php?proid=276">View</a> &nbsp;
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="uk-width-medium-1-4 uk-panel jswidth25 block_product">
                                            <div class="product productitem_11">
                                                <div class="image">
                                                    <div class="image_block">
                                                        <div class="product_label">
                                                        </div>
                                                        <a href="detail.php?proid=276">
                                                        <img class="jshop_img" src="images/pic/IMG-20190221-WA0041.jpg" style="height: 300px;" alt="" title="">
                                                        </a>
                                                        <div class="name">
                                                            <h2 class="product_title"><a href="detail.php?proid=276">Hoodies</a></h2>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="mainblock">
                                                    <div class="price-wrap">
                                                        <div class="jshop_price" style="color: white;"><span>
                                                            Art no.</span>
                                                        </div>
                                                        <div class="jshop_price">
                                                            <span>151</span>
                                                        </div>
                                                    </div>
                                                    <div class="buttons">
                                                        <a class="button_buy" href="detail.php?proid=276">View</a> &nbsp;
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                               
                            </div>
                        </div>
                    </main>
                </div>
            </div>
        </div>


        <!---->

<!--Featured Products-->

         <div class="tm-bottom-c-box tm-full-width  ">
            <div class="uk-container uk-container-center">
                <section id="tm-bottom-c" class="tm-bottom-c uk-grid" data-uk-grid-match="{target:'> div > .uk-panel'}" data-uk-grid-margin="">

                    <div class="uk-width-1-1">
                        <div class="uk-panel">
                            <div class="shop-main-page-wrap">
                                <div class="container uk-container-center">
                                    <div class="uk-grid">
                                        <div class="uk-width-1-1">
                                            <div class="shop-title">
                                                <h2>Featured <span>Products</span></h2>
                                            </div>
                                        </div>
                                       
                                    </div>
                                </div>


                                <div class="latest_products jshop">

                                    <div data-uk-slider="{center:true, autoplay:true, pauseOnHover:true, autoplayInterval:5000}">

                                        <div class="uk-slider-container">
                                            <ul class="uk-slider uk-grid-width-large-1-6 uk-grid-width-medium-1-4 uk-grid-width-small-1-1  uk-grid uk-grid-medium">

                                                <li class="block_item">

                                                    <div class="image">
                                                        <div class="image_block">
                                                            <a draggable="false" href="products.php?cat=hoodies">
                                                                <img draggable="false" class="" src="images/pic/1.jpg" style="height: 200px;" alt="" height="100%" width="100%" >
                                                            </a>
                                                        </div>
                                                        <div class="name">
                                                            <a draggable="false" href="products.php?cat=hoodies">Hoodies</a>
                                                        </div>
                                                    </div>
                                                    <div class="actions-wrap">
                                                        <div class="price-wrap">
                                                            <div class="jshop_price" style="color: white;"><span>Art no.</span></div>

                                                            <div class="jshop_price">
                                                                <span>156</span>
                                                            </div>
                                                        </div>

                                                        <div class="buttons">
                                                            <a draggable="false" class="button_buy" href="products.php?cat=hoodies">View</a> 
                                                        </div>

                                                    </div>
                                                </li>

                                                <li class="block_item" >

                                                    <div class="image"width="100px" height="100px">
                                                        <div class="image_block">
                                                            <a draggable="false" href="products.php?cat=hoodies">
                                                                <img draggable="false" class="" src="images/pic/2.jpg" alt="" style="height: 200px;" >
                                                            </a>
                                                        </div>
                                                        <div class="name">
                                                            <a draggable="false" href="products.php?cat=hoodies">Hoodies</a>
                                                        </div>
                                                    </div>
                                                    <div class="actions-wrap">
                                                        <div class="price-wrap">
                                                            <div class="jshop_price" style="color: white;"><span>Art no.</span></div>

                                                            <div class="jshop_price">
                                                                <span>155</span>
                                                            </div>
                                                        </div>

                                                        <div class="buttons">
                                                            <a draggable="false" class="button_buy" href="products.php?cat=hoodies">View</a> 
                                                        </div>

                                                    </div>
                                                </li>

                                               <li class="block_item">

                                                    <div class="image">
                                                        <div class="image_block">
                                                            <a draggable="false" href="products.php?cat=hoodies">
                                                                <img draggable="false" class="jshop_img" src="images/pic/3.jpg" alt="" style="height: 200px;">
                                                            </a>
                                                        </div>
                                                        <div class="name">
                                                            <a draggable="false" href="products.php?cat=hoodies">Hoodies</a>
                                                        </div>
                                                    </div>
                                                    <div class="actions-wrap">
                                                        <div class="price-wrap">
                                                           <div class="jshop_price" style="color: white;"><span>Art no.</span></div>

                                                            <div class="jshop_price">
                                                                <span>154</span>
                                                            </div>
                                                        </div>

                                                        <div class="buttons">
                                                            <a draggable="false" class="button_buy" href="products.php?cat=hoodies">View</a> 
                                                        </div>

                                                    </div>
                                                </li>

                                                <li class="block_item">

                                                    <div class="image">
                                                        <div class="image_block">
                                                            <a draggable="false" href="products.php?cat=hoodies">
                                                                <img draggable="false" class="jshop_img" src="images/pic/4.jpg" alt="" style="height: 200px;" >
                                                            </a>
                                                        </div>
                                                        <div class="name">
                                                            <a draggable="false" href="products.php?cat=hoodies">Hoodies</a>
                                                        </div>
                                                    </div>
                                                    <div class="actions-wrap">
                                                        <div class="price-wrap">
                                                            <div class="jshop_price" style="color: white;"><span>Art no.</span></div>

                                                            <div class="jshop_price">
                                                                <span>153</span>
                                                            </div>
                                                        </div>

                                                        <div class="buttons">
                                                            <a draggable="false" class="button_buy" href="products.php?cat=hoodies">View</a> 
                                                        </div>

                                                    </div>
                                                </li>

                                                <li class="block_item">

                                                    <div class="image">
                                                        <div class="image_block">
                                                            <a draggable="false" href="products.php?cat=leatherjackets">
                                                                <img draggable="false" class="jshop_img" src="images/pic/5.jpg" alt="" style="height: 200px;" >
                                                            </a>
                                                        </div>
                                                        <div class="name">
                                                            <a draggable="false" href="products.php?cat=leatherjackets">Jackets</a>
                                                        </div>
                                                    </div>
                                                    <div class="actions-wrap">
                                                        <div class="price-wrap">
                                                            <div class="jshop_price" style="color: white;"><span>Art no.</span>
                                                            </div>

                                                            <div class="jshop_price">
                                                                <span>151</span>
                                                            </div>
                                                        </div>

                                                        <div class="buttons">
                                                            <a draggable="false" class="button_buy" href="products.php?cat=jacket">View</a> 
                                                        </div>

                                                    </div>
                                                </li>
                                                
                                                    <li class="block_item">

                                                    <div class="image">
                                                        <div class="image_block">
                                                            <a draggable="false" href="products.php?cat=hoodies">
                                                                <img draggable="false" class="jshop_img" src="images/pic/7.jpg" alt="" style="height: 200px;" >
                                                            </a>
                                                        </div>
                                                        <div class="name">
                                                            <a draggable="false" href="products.php?cat=hoodies">Hoodies</a>
                                                        </div>
                                                    </div>
                                                    <div class="actions-wrap">
                                                        <div class="price-wrap">
<div class="jshop_price" style="color: white;"><span>Art no.</span>                                                            </div>

                                                            <div class="jshop_price">
                                                                <span>152</span>
                                                            </div>
                                                        </div>

                                                        <div class="buttons">
                                                            <a draggable="false" class="button_buy" href="products.php?cat=hoodies">View</a> 
                                                        </div>

                                                    </div>
                                                </li>

                                                <li class="block_item">

                                                    <div class="image">
                                                        <div class="image_block">
                                                            <a draggable="false" href="products.php?cat=hoodies">
                                                                <img draggable="false" class="jshop_img" src="images/pic/8.jpg" alt=""style="height: 200px;" >
                                                            </a>
                                                        </div>
                                                        <div class="name">
                                                            <a draggable="false" href="products.php?cat=hoodies">Hoodies</a>
                                                        </div>
                                                    </div>
                                                    <div class="actions-wrap">
                                                        <div class="price-wrap">
<div class="jshop_price" style="color: white;"><span>Art no.</span>                                                            </div>

                                                            <div class="jshop_price">
                                                                <span>150</span>
                                                            </div>
                                                        </div>

                                                        <div class="buttons">
                                                            <a draggable="false" class="button_buy" href="products.php?cat=hoodies">View</a> 
                                                        </div>

                                                    </div>
                                                </li>

                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="fun-shop-btn">
                                    <a href="products.php?cat=featured"><span>View all</span></a>
                                </div>
                                                                                                            
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>


<!--/Featured Products-->
        

       


       
          <?php include'footer.php'; ?>